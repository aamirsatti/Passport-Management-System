<?php 

echo "record submited";

?>

